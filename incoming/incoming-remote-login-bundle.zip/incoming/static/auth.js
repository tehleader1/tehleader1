(() => {
  const AUTH_BASE = "https://supportrd.com";
  const LOGIN_URL = `${AUTH_BASE}/account/login`;
  const REGISTER_URL = `${AUTH_BASE}/account/register`;
  const LOGOUT_URL = `${AUTH_BASE}/account/logout`;
  const PREMIUM_URL = "https://supportrd.com/products/hair-advisor-premium";
  const PRO_URL = "https://supportrd.com/products/professional-hair-advisor";

  const qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const qs = (sel, root = document) => root.querySelector(sel);

  function safeParse(value, fallback = {}) {
    try { return JSON.parse(value); } catch { return fallback; }
  }

  function routeTag() {
    let tag = localStorage.getItem("supportrdRouteTag");
    if (!tag) {
      const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
      tag = "^^ " + Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
      localStorage.setItem("supportrdRouteTag", tag);
    }
    return tag;
  }

  function profileFromQuery() {
    const url = new URL(window.location.href);
    const email = (url.searchParams.get("email") || "").trim();
    const name = (url.searchParams.get("name") || "").trim();
    const loggedIn = url.searchParams.get("logged_in") === "true" || url.searchParams.get("login") === "confirmed";
    return { email, name, loggedIn };
  }

  function getProfile() {
    const saved = safeParse(localStorage.getItem("accountProfile") || "{}", {});
    const social = safeParse(localStorage.getItem("socialLinks") || "{}", {});
    const q = profileFromQuery();
    const email = q.email || saved.email || social.email || "";
    const name = q.name || saved.name || social.name || email || "Logged In";
    const loggedIn = q.loggedIn || localStorage.getItem("loggedIn") === "true" || !!email;
    const profile = { loggedIn, email, name, tag: saved.tag || routeTag() };
    if (loggedIn) {
      localStorage.setItem("loggedIn", "true");
      localStorage.setItem("accountProfile", JSON.stringify(profile));
    }
    return profile;
  }

  function authUrl(kind, provider) {
    const url = new URL(kind === "signup" ? REGISTER_URL : LOGIN_URL);
    if (provider) url.searchParams.set("provider", provider);
    const profile = getProfile();
    if (profile.email) url.searchParams.set("login_hint", profile.email);
    return url.toString();
  }

  function providerFrom(el) {
    const id = (el.id || "").toLowerCase();
    const href = (el.getAttribute && (el.getAttribute("href") || "")) || "";
    if (id.includes("google") || href.includes("google-oauth2")) return "google-oauth2";
    if (id.includes("microsoft") || href.includes("windowslive")) return "windowslive";
    if (id.includes("yahoo") || href.includes("yahoo")) return "yahoo";
    if (id.includes("phone") || href.includes("provider=sms")) return "sms";
    return "";
  }

  function classify(el) {
    if (!el) return null;
    const id = (el.id || "").toLowerCase();
    const href = (el.getAttribute && (el.getAttribute("href") || "")) || "";
    const text = (el.textContent || "").trim().toLowerCase();
    const provider = providerFrom(el);
    if (id === "logoutbtn" || href === "/logout" || href.includes("/account/logout") || text === "log out") return { kind: "logout", provider };
    if (id === "signuptop" || text.includes("sign up") || text.includes("signup") || href.includes("mode=signup") || href.includes("/account/register")) return { kind: "signup", provider };
    if (id === "loginbtn" || id.startsWith("login") || text.includes("log in") || text.includes("sign in") || href === "/login" || href.includes("/account/login")) return { kind: "login", provider };
    return null;
  }

  function rewriteLinks() {
    qsa("a[href]").forEach((a) => {
      const href = a.getAttribute("href") || "";
      if (href === "/logout" || href.includes("/account/logout")) a.setAttribute("href", LOGOUT_URL);
      else if (href.includes("mode=signup") || href.includes("/account/register")) a.setAttribute("href", authUrl("signup", providerFrom(a)));
      else if (href === "/login" || href.includes("/account/login")) a.setAttribute("href", authUrl("login", providerFrom(a)));
    });
  }

  document.addEventListener("click", (event) => {
    const el = event.target && event.target.closest ? event.target.closest("a,button,[role='button']") : null;
    const info = classify(el);
    if (!info) return;
    event.preventDefault();
    event.stopPropagation();
    if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    if (info.kind === "logout") {
      localStorage.removeItem("loggedIn");
      localStorage.removeItem("accountProfile");
      window.location.href = LOGOUT_URL;
      return;
    }
    window.location.href = authUrl(info.kind, info.provider);
  }, true);

  async function syncProfile() {
    rewriteLinks();
    try {
      const res = await fetch("/api/me", { credentials: "same-origin" });
      const data = await res.json();
      if (data && data.authenticated && data.user) {
        const profile = {
          loggedIn: true,
          email: (data.user.email || "").trim(),
          name: (data.user.name || data.user.nickname || data.user.email || "Logged In").trim(),
          tag: routeTag(),
        };
        localStorage.setItem("loggedIn", "true");
        localStorage.setItem("accountProfile", JSON.stringify(profile));
      }
    } catch {}
  }

  function decorateTopBar() {
    const profile = getProfile();
    if (!profile.loggedIn) return;
    const badge = qs("#userBadge");
    const sub = qsa(".system-sub")[0];
    const loginBtn = qs("#loginBtn");
    const signupTop = qs("#signupTop");
    const logoutBtn = qs("#logoutBtn");
    if (loginBtn) loginBtn.style.display = "none";
    if (signupTop) signupTop.style.display = "none";
    if (logoutBtn) logoutBtn.style.display = "inline-flex";
    if (badge) {
      badge.style.display = "inline-flex";
      badge.textContent = `Logged In ${profile.tag}`;
      badge.title = profile.email || profile.name;
      if (!qs("#accountPlans")) {
        const wrap = document.createElement("div");
        wrap.id = "accountPlans";
        wrap.style.cssText = "display:inline-flex;gap:8px;flex-wrap:wrap;margin-left:10px";
        wrap.innerHTML = `<a href="${PREMIUM_URL}" target="_blank" rel="noopener">Premium</a> <a href="${PRO_URL}" target="_blank" rel="noopener">Pro</a>`;
        badge.insertAdjacentElement("afterend", wrap);
      }
    }
    if (sub) sub.textContent = `${profile.email || profile.name} ${profile.tag} · Premium / Pro available`;
  }

  document.addEventListener("DOMContentLoaded", () => { syncProfile(); decorateTopBar(); });
  window.addEventListener("load", () => { syncProfile(); decorateTopBar(); });
  setInterval(() => { syncProfile(); decorateTopBar(); }, 1500);
  if (window.location.pathname === "/login") window.location.replace(authUrl("login"));
  if (window.location.pathname === "/logout") window.location.replace(LOGOUT_URL);
  window.login = function () { window.location.href = authUrl("login"); };
})();
