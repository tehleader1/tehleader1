var auth0 = new auth0.WebAuth({
domain: "YOUR_AUTH0_DOMAIN",
clientID: "YOUR_AUTH0_CLIENT",
redirectUri: window.location.origin,
responseType: "token id_token",
scope: "openid profile email"
})

function login(){
auth0.authorize()
}


document.addEventListener("DOMContentLoaded", ()=>{document.querySelectorAll(`a[href^="/login"],a[href^="/logout"]`).forEach(a=>{const h=a.getAttribute("href")||"";if(h.startsWith("/logout")) a.href="https://ai-hair-advisor.onrender.com/logout"; else a.href=`https://ai-hair-advisor.onrender.com${h}`;});});
